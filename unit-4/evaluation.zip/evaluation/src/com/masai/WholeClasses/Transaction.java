package com.masai.WholeClasses;

public class Transaction {
      Transaction(){
    	  
      }
}
